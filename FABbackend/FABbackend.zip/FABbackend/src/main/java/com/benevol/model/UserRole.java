
package com.benevol.model;

public enum UserRole {
    VISITOR,
    ASSOCIATION,
    ANIMATOR,
    ACCOUNTANT,
    ADMIN
}
