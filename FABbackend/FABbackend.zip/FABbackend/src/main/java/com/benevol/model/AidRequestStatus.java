
package com.benevol.model;

public enum AidRequestStatus {
    PENDING,
    APPROVED,
    REJECTED,
    COMPLETED
}
