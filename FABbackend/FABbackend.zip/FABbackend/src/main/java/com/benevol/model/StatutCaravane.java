
package com.benevol.model;

public enum StatutCaravane {
    PLANNED,
    ACTIVE,
    COMPLETED,
    CANCELLED
}
