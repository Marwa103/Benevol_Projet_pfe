package com.benevol.model;

public enum PublicationType {
    EVENT,
    CARAVAN,
    ANNOUNCEMENT
}
