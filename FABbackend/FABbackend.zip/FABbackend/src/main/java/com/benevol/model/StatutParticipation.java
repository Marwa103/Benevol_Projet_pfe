
package com.benevol.model;

public enum StatutParticipation {
    PENDING,
    CONFIRMED,
    REJECTED
}
