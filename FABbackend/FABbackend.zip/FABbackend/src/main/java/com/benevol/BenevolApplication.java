package com.benevol;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BenevolApplication {

	public static void main(String[] args) {
		SpringApplication.run(BenevolApplication.class, args);
	}

}
