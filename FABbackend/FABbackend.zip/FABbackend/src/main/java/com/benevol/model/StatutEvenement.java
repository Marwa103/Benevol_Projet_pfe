
package com.benevol.model;

public enum StatutEvenement {
    PLANNED,
    ACTIVE,
    COMPLETED,
    CANCELLED
}
