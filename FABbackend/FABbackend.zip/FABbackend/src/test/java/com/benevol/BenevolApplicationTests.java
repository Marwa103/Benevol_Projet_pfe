package com.benevol;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BenevolApplicationTests {

	@Test
	void contextLoads() {
	}

}
